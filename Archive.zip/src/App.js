import './App.css';


function Groupxy() {
  return ( <div className='Groupxy2'> <div className="musicplayer-image">
  <img src="https://media.istockphoto.com/id/2161069152/photo/man-singing-into-a-microphone-with-a-colored-background.jpg?s=2048x2048&w=is&k=20&c=bxE6fzK9o3tlMq9PvTyssdLCRhrdtdMbsPgpqFea6MY=" alt="Profile" style={{ width: "164px", height: "100%" }}  />
</div><div className="Groupxy">
   
    <div className="audioControler1"> <span className="playSign">▶️</span>    <span className="playSignTitle">-50% OFF, EXPIRES SO...</span></div>
    <div className="audioControler2" > <span className="audioControler2a" > </span> <span className="audioControler2b">-20:10</span> </div>
    <div className="audioControler3"> <div></div> <div></div> <div></div> <div></div> <div></div> </div>
    </div> </div>)
}


function Groupx() {
  return (
    <div className="ad-container">
      {/* Profile Image */}
      <div className="profile-image">
        <img src="https://media.istockphoto.com/id/2161069152/photo/man-singing-into-a-microphone-with-a-colored-background.jpg?s=2048x2048&w=is&k=20&c=bxE6fzK9o3tlMq9PvTyssdLCRhrdtdMbsPgpqFea6MY=" alt="Profile"  />
      </div>

      {/* Text Details */}
      <div className="ad-details">
        <div className="ad-promotion">-50% OFF, EXPIRES SO...</div>
        <div className="ad-title">Lesyo</div>
        
      </div>

      {/* Action Buttons */}
      <div className="ad-actions">
        <button className="add-to-cart">
          <img src="https://media.istockphoto.com/id/1153439787/vector/setting-gear-tool-cog-isolated-flat-web-mobile-icon-vector-sign-symbol-button-element.jpg?s=2048x2048&w=is&k=20&c=9q3Q3iK2EekwiJQqHzhLomkrphqdSbEz375tOhM7-h8="
            alt="Cart Icon" />
        </button>
        <button className="add-to-favorites">
          <img src="https://media.istockphoto.com/id/1251362621/photo/shopping-cart-vector-art-closeup-view.jpg?s=1024x1024&w=is&k=20&c=a8IFbSzW0jhgJKnJGhx0TCDEKYOfDRNUFB_6ODy_oJI=" alt="Favorite Icon" />
        </button>
        <button className="more-options">⋮</button>
      </div>
    </div>
  );
}

function Headerlogo() {
  return (
    <a href="/" className="Headerlogo">
      <img src="./beathub1.jpg" style={{ width: "64px", height: "64px" }} ></img>
    </a>
  );
}

function HeaderSearchBar() {
  return (
    <input type="text" className="HeaderSearchBar" value=" 🔎 search for your song"></input>
  );
}

function HeaderCartIcon() {
  return (
    <div className="HeaderCartIcon">
      <img src="https://cdn-icons-png.flaticon.com/512/1170/1170678.png" alt="Cart Icon" className="HeaderCartIcon" />
    </div>
  );
}


function GroupA() {
  return (
    <div className="GroupA"><Headerlogo /> <HeaderSearchBar /> <HeaderCartIcon />  </div>
  );
}

function GroupB() {
  return (
    <div className="GroupB">

      <div style={{ fontSize: "25px", margin: "30px 0 180px 0" }}>BeatHub is a brand that supports afrobeat artist</div>
      <div className="">
      <h1 style={{ color: "Tomato" }}>BeatHub is a brand that supports afrobeat artist</h1>
      <h5 style={{ fontSize: "0.6em", padding: "0 180px"}}>BeatHub is a brand that supports afrobeat artist BeatHub is a brand that supports afrobeat artist BeatHub is a brand that supports afrobeat artist</h5>
    </div> </div>
  );
}

function GroupBa() {
  return (
    <div className="GroupBa"> <Groupxy/> <Groupx /> <Groupx /> <Groupx /> <Groupx />  </div>
  );
}

function GroupCa() {
  return (
    <div className="GroupCa">  </div>
  );
}

function GroupCb() {
  return (
    <div className="GroupCb"> </div>
  );
}

function GroupC() {
  return (
    <div className="GroupC"></div>
  );
}

function App() {
  return (
    <div className="App">
      <header className="App-header">


        <GroupA />
        <GroupB />
        <GroupBa />
        <GroupCa />
        <GroupCb />
        <GroupCa />
        <GroupC />
        <GroupC />
      </header>
    </div>
  );
}

export default App;
